# Spryngtime's Azure OpenAI wrapper


Quickstart:
Replace 
import openai
with

import SpryngtimeOpenAI as openai

Notes for Spryngtime's OpenAI wrapper:
- Make sure to take requirements.txt and put into setup.py